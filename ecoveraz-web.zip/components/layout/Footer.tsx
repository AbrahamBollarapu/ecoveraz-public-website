import { Container } from "./Container";
import { Divider } from "../ui/Divider";

const DISCLAIMERS = [
  "Alignment ≠ certification",
  "Visuals may be illustrative",
  "Capabilities vary by deployment",
  "Verification ≠ regulatory approval",
];

export function Footer() {
  return (
    <footer className="mt-16 border-t border-border-700 bg-bg-900">
      <Container>
        <div className="py-10">
          <div className="text-sm font-semibold text-text-200">Disclosures</div>
          <div className="mt-3 grid grid-cols-1 gap-2 md:grid-cols-2">
            {DISCLAIMERS.map((d) => (
              <div key={d} className="text-sm text-text-300">
                {d}
              </div>
            ))}
          </div>

          <div className="my-8">
            <Divider />
          </div>

          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <div className="text-sm text-text-400">© {new Date().getFullYear()} EcoVeraZ. All rights reserved.</div>
            <div className="text-sm text-text-400">Operational evidence infrastructure.</div>
          </div>
        </div>
      </Container>
    </footer>
  );
}
