export function Divider() { return <div className="h-px w-full bg-border-700" />; }
