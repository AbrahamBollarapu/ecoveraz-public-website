import { Container } from "@/components/layout/Container";
import { Card, CardHeader } from "@/components/ui/Card";
import { StatusBadge } from "@/components/ui/StatusBadge";

export default function Page() {
  return (
    <Container>
      <div className="py-10">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <div className="text-2xl font-semibold text-text-100">Module</div>
            <div className="mt-1 text-sm text-text-300">Template placeholder (Phase 4A)</div>
          </div>
          <StatusBadge tone="neutral" mono>
            BUILD MODE
          </StatusBadge>
        </div>

        <Card>
          <CardHeader title="Scaffold ready" subtitle="Next: Phase 4B page builds (Homepage first)." />
          <div className="text-sm text-text-300">
            This page is intentionally minimal. It exists to validate tokens, layout chrome, and routing.
          </div>
        </Card>
      </div>
    </Container>
  );
}
